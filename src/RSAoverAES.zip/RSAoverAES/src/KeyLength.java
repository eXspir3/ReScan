/**
 * Enum für die für kryptographische Operationen verwendeten Schlüssellängen.
 *
 * @author Raphael Zoidl
 */
public enum KeyLength {
    /** 128 Bit Schlüssellänge */
    BIT_128( 128, 16 ),
    /** 192 Bit Schlüssellänge */
    BIT_192( 192, 24 ),
    /** 256 Bit Schlüssellänge */
    BIT_256( 256, 32 );

    /** Schlüssellänge in Bits */
    int keyLengthInBits;
    /** Schlüssellänge in Bytes */
    int keyLengthInBytes;

    /**
     * Konstruktor
     *
     * @param keyLengthInBits {@link #keyLengthInBits}
     * @param keyLengthInBytes {@link #keyLengthInBytes}
     */
    KeyLength( int keyLengthInBits, int keyLengthInBytes ) {
        this.keyLengthInBits = keyLengthInBits;
        this.keyLengthInBytes = keyLengthInBytes;
    }

    /**
     * Liefert den Wert von {@link #keyLengthInBits}.
     *
     * @return {@link #keyLengthInBits}
     */
    public int getKeyLengthInBits() {
        return this.keyLengthInBits;
    }

    /**
     * Liefert den Wert von {@link #keyLengthInBytes}.
     *
     * @return {@link #keyLengthInBytes}
     */
    public int getKeyLengthInBytes() {
        return this.keyLengthInBytes;
    }
}